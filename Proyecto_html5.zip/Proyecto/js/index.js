$(function(){
  var width   = 200,
      height  = 44 * 4 + 20,
      speed   = 300,
      button  = $('#menu-button'),
      overlay = $('#overlay'),
      menu    = $('#hamburger-menu');

      var tienda = document.querySelector('.shop');
      var contacto = document.querySelector('.contact');
      var fondo = document.querySelector(".home");
      var about = document.querySelector(".about");
      var team = document.querySelector(".team");


  button.on('click',function(e){
    if(overlay.hasClass('open')) {
      animate_menu('close');
    } else {
      animate_menu('open');
    }
  });

  overlay.on('click', function(e){
    if(overlay.hasClass('open')) {
      animate_menu('close');
    }
  });

  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });

  function animate_menu(menu_toggle) {
    if(menu_toggle == 'open') {
      overlay.addClass('open');
      button.addClass('on');
      overlay.animate({opacity: 1}, speed);
      menu.animate({width: width, height: height}, speed);
    }

    if(menu_toggle == 'close') {
      button.removeClass('on');
      overlay.animate({opacity: 0}, speed);
      overlay.removeClass('open');
      menu.animate({width: "0", height: 0}, speed);
    }
  }

  var boton_tienda = document.querySelector("#shop");
  boton_tienda.onclick = function(evt) {
      evt.preventDefault();
      tienda.style.display = "block";
      fondo.style.display = "none";

      if(contacto.style.display="block"){
        contacto.style.display="none";
      }
      if(about.style.display="block"){
        about.style.display="none";
      }
      if(team.style.display="block"){
        team.style.display="none";
      }

      if(overlay.hasClass('open')) {
        animate_menu('close');
      }
      document.body.style['overflow-y'] = 'scroll';

  };

  var boton_contacto = document.querySelector('#contact');
  boton_contacto.onclick = function(event){
    event.preventDefault();
    contacto.style.display = "block";
    fondo.style.display = "none";

    if(tienda.style.display="block"){
      tienda.style.display="none";
    }
    if(about.style.display="block"){
      about.style.display="none";
    }
    if(team.style.display="block"){
      team.style.display="none";
    }
    if(document.body.style['overflow-y'] = 'scroll'){
      document.body.style['overflow-y'] = 'hidden';
    }

    if(overlay.hasClass('open')) {
      animate_menu('close');
    }

    $(document).ready(function(){
      setTimeout(myMap, 50);
    });
  };

  var boton_about = document.querySelector('#about');
  boton_about.onclick = function(event){
    event.preventDefault();
    about.style.display = "block";
    fondo.style.display = "none";

    if(tienda.style.display="block"){
      tienda.style.display="none";
    }
    if(contacto.style.display="block"){
      contacto.style.display="none";
    }
    if(team.style.display="block"){
      team.style.display="none";
    }
    if(document.body.style['overflow-y'] = 'scroll'){
      document.body.style['overflow-y'] = 'hidden';
    }
    if(overlay.hasClass('open')) {
      animate_menu('close');
    }
    
    // Automatic Slideshow - change image every 4 seconds
    var myIndex = 0;
    carousel();

    function carousel() {
        var i;
        var x = document.getElementsByClassName("mySlides");
        for (i = 0; i < x.length; i++) {
           x[i].style.display = "none";
        }
        myIndex++;
        if (myIndex > x.length) {myIndex = 1}
        x[myIndex-1].style.display = "block";
        setTimeout(carousel, 2000);
    }

  };

  var boton_team = document.querySelector('#team');
  boton_team.onclick = function(event){
    event.preventDefault();
    team.style.display = "block";
    fondo.style.display = "none";

    if(tienda.style.display="block"){
      tienda.style.display="none";
    }
    if(about.style.display="block"){
      about.style.display="none";
    }
    if(contacto.style.display="block"){
      contacto.style.display="none";
    }

    if(overlay.hasClass('open')) {
      animate_menu('close');
    }
    document.body.style['overflow-y'] = 'scroll';

  };
});
